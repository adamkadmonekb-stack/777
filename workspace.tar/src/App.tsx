import { useEffect, useRef } from 'react';
import { Game } from './game/Game';

export default function App() {
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const el = ref.current;
    if (!el || el.dataset.mounted) return;
    el.dataset.mounted = '1';
    const game = new Game(el);
    return () => game.destroy();
  }, []);

  return <div ref={ref} className="app-root" />;
}
